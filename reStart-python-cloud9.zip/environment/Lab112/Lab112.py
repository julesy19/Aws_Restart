print("Bonjour  Mamadou ")
print("*" * 50)
print("Lab 112")
print("*" * 50)

myMixedTypeList = [45, 290578, 1.02, True, "My dog is on the bed.", "45"]

for item in myMixedTypeList:
    print("{} is of the data type {}".format(item,type(item)))
    
    